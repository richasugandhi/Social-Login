<?php
define('CONSUMER_KEY', 'J5JxpYQvuSvEFqVR5RaD5W1j5'); // YOUR CONSUMER KEY
define('CONSUMER_SECRET', 'd11e0IRpNfyxYspDNNiWimwWLyQrJTWNL0UKNmILEbkbQPsPfw'); //YOUR CONSUMER SECRET KEY 
define('OAUTH_CALLBACK', 'http://localhost/twitter/twitter/index.php');  // Redirect URL 

session_start();
?>